///////////////////////////////////////////////
//
// **************************
// ** ENGLISH - 07/07/2012 **
//
// Project/Software name: libObfuscate v2.00
// Contact: "EmbeddedSW" <embedded@embeddedsw.net>
// Company: EmbeddedSW.net
//
// THIS IS A FREE SOFTWARE
//
// This software is released under GNU LGPL:
//
// * LGPL 3.0 <http://www.gnu.org/licenses/lgpl.html>
//
// You're free to copy, distribute and make commercial use
// of this software under the following conditions:
//
// * You have to cite the author (and copyright owner): EmbeddedSW
// * You have to provide a link to the author's Homepage: <http://www.embeddedsw.net/>
//
///////////////////////////////////////////////

#ifndef CLEFIA_DATA_H
#define CLEFIA_DATA_H

// ** Thread-safe implementation

// ** Clefia cipher
// ** 128bit block size
// ** 256bit key

typedef struct {
	int		r;
	BYTE	rk[8 * 26 + 16];
} CLEFIA_DATA;

#endif
