var contact = '<h4>&nbsp;</h4>'+
'<h2 style="font-variant:small-caps;"><b>Contact Us</b></h2>'+
'<table><tr>'+
'<td valign="middle"><h3>'+
'<a href="mailto:embedded@embeddedsw.net"><img src="./images/email-support.png" alt="email-support.png"></a>&nbsp;'+
'<a href="skype:embeddedsw.company?call"><img src="./images/skype.png" alt="skype.png"></a>&nbsp;'+
'<a href="http://www.facebook.com/pages/EmbeddedSW/228431677213272"><img src="./images/facebook.png" alt="facebook.png"></a>&nbsp;'+
'<a href="http://www.youtube.com/user/embeddedswnet"><img src="./images/youtube.png" alt="youtube.png"></a>&nbsp;'+
'</h3></td>'+
'</tr></table>'+
'<h4>&nbsp;</h4>';

document.write(contact);