var footer = '<h3><i>Design by <a class="darkgrey" href="http://embeddedsw.net/">EmbeddedSW.net</a> | <a class="darkgrey" href="https://ikornapostur.1984.is/src/login.php">SquirrelMail</a> | Worldwide <a class="darkgrey" href="http://www.whatsmydns.net/#A/embeddedsw.net">DNS</a> propagation</i></h3>'+
'<h3><i>Pictures and media inside this domain are released under <a class="darkgrey" href="http://creativecommons.org/licenses/by/3.0/">Creative Commons 3.0</a></i></h3>';

document.write(footer);