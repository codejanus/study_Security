- MoonSols Windows Memory Toolkit 1.1.20110201 - 
- Professional Edition - Single User License - 

MoonSols Windows Memory Toolkit
Copyright (C) 2010, Matthieu Suiche <http://www.msuiche.net>
Copyright (C) 2010, MoonSols <http://www.moonsols.com>

All executables and drivers are NOT redistributable, and licence applies only to one single
user. Reverse engineering is prohibited.

You are experiencing any problems contact us at : support@moonsols.com

This version contains :

 - win32dd  (one executable + one driver) 1.3.2.20110201
 - win64dd  (one executable + one driver) 1.3.2.20110201
 - hibr2dmp (one executable)              1.0.20100405
 - hibr2bin (one executable)              1.0.20100405
 - dmp2bin  (one executable)              1.0.20100405
 - bin2dmp  (one executable)              1.0.20100405
 
 - scripts\x64_dmp_ask.cmd                Execute win64dd, create a Microsoft crash dump in dumps directory 
                                          and a trace log in log directory - Before the creation of the memory
                                          it ask for a confirmation.
 - scripts\x64_dmp_do_NOT_ask.cmd         Execute win64dd, create a Microsoft crash dump in dumps directory 
                                          and a trace log in log directory without asking for a confirmation.

 - scripts\x64_raw_ask.cmd                Execute win64dd, create a raw memory dump in dumps directory and a 
                                          trace log in log directory - Before the creation of the memory it
                                          ask for a confirmation.
 - scripts\x64_raw_do_NOT_ask.cmd         Execute win64dd, create a raw memory dump in dumps directory and a 
                                          trace log in log directory without asking for a confirmation.


 - scripts\x86_dmp_ask.cmd                Execute win32dd, create a Microsoft crash dump in dumps directory 
                                          and a trace log in log directory - Before the creation of the memory
                                          it ask for a confirmation.

 - scripts\x86_dmp_do_NOT_ask.cmd         Execute win32dd, create a Microsoft crash dump in dumps directory 
                                          and a trace log in log directory without asking for a confirmation.

 - scripts\x86_raw_ask.cmd                Execute win32dd, create a raw memory dump in dumps directory and a 
                                          trace log in log directory - Before the creation of the memory it
                                          ask for a confirmation.
 - scripts\x86_raw_do_NOT_ask.cmd         Execute win32dd, create a raw memory dump in dumps directory and a 
                                          trace log in log directory without asking for a confirmation.

You registered for the Professional Edition which means :

 - win32dd works for Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7 32-bits Edition.
 - win64dd works for Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7 64-bits (x64) Edition.
 You can both uses win32dd and/or win64dd with scripts or/and batch file. And you can also benefit
 of the interactive mode for the acquisition.
 * Not possible with Community Edition.

 - hibr2dmp and hibr2bin works with Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7
 32-bits and 64-bits (x64) Microsoft Windows hibernation files, including corrupted
 hibernation files. And the produced file is hashed with md5 algorithm.
  * Community version only supports 32-bits Microsoft Windows hibernation files from XP to Vista. 

 - dmp2bin works with Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7 32-bits and 64-bits (x64)
 Microsoft full memory crash dump files. And the produced file is hashed with md5 algorithm.
  * Community version only supports 32-bits Microsoft crash dump.

 - bin2dmp works with Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7 32-bits and
 64-bits (x64) raw memory snapshots (windd, VMWare).
 And the produced file is hashed with md5 algorithm.
  * Community version only supports 32-bits images from XP to Vista. 


