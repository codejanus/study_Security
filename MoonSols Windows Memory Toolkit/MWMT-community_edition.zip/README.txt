- MoonSols Windows Memory Toolkit 1.0.20100417 - 
- Community Edition -

MoonSols Windows Memory Toolkit
Copyright (C) 2010, Matthieu Suiche <http://www.msuiche.net>
Copyright (C) 2010, MoonSols <http://www.moonsols.com>

This version is free. All executables and drivers are NOT redistributable.
Reverse engineering is prohibited.

You are experiencing any problems contact us at : support@moonsols.com

This version contains :

 - win32dd  (one executable + one driver) 1.3.1.20100417
 - win64dd  (one executable + one driver) 1.3.1.20100417
 - hibr2dmp (one executable)              1.0.20100405
 - hibr2bin (one executable)              1.0.20100405
 - dmp2bin  (one executable)              1.0.20100405
 - bin2dmp  (one executable)              1.0.20100405

You are using Community Edition which means :

 - win32dd works for Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7 32-bits Edition.
 - win64dd works for Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7 64-bits (x64) Edition.

 - hibr2dmp and hibr2bin only works with Microsoft Windows XP, 2003, 2008, Vista 32-bits Edition
   Microsoft Windows hibernation files, including corrupted hibernation files.

 - dmp2bin only works with Microsoft Windows XP, 2003, 2008, Vista, 2008 R2, 7 32-bits Edition
  of Microsoft full memory crash dump files.

 - bin2dmp works with Microsoft Windows XP, 2003, 2008, Vista 32-bits Edition raw memory snapshots
 (windd, VMWare -- Can also work with Live VMWare Virtual Machine but only in the Professional Edition).).