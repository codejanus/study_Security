# officeLibSample
Microsoft Office Activity Forensics Library Sample Code.
Trace used office activity
  - C#.NET Library
  - more than .NET Framework 3.5 
  - Library Download : http://rav2e.tistory.com/entry/Microsoft-Office-Activity-Record-Trace-Library-v10-in-CNET
  - FAQ : namegpark@gmail.com
