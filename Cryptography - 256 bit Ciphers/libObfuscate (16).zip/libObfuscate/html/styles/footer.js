var footer = '<h3><i>Web design by EmbeddedSW.net | <a class="darkgrey" href="https://ikornapostur.1984.is/src/login.php">SquirrelMail</a> | Worldwide <a class="darkgrey" href="http://www.whatsmydns.net/#A/embeddedsw.net">DNS</a> propagation | Our <a class="darkgrey" href="http://embeddedsw.net/Embeddedsw_privacy.html">Privacy</a> policy</i></h3>'+
'<h3><i>Unless different specifications, pictures and media inside this domain are released under <a class="darkgrey" href="http://creativecommons.org/licenses/by/4.0/">CC-by-4.0</a></i></h3>';

document.write(footer);