///////////////////////////////////////////////
//
// **************************
// ** ENGLISH - 04/03/2014 **
//
// Project: libObfuscate v2.00
// Company: EmbeddedSW.net
//
// THIS IS A FREE SOFTWARE
//
// This software is released under:
//
// * LGPL 3.0: http://www.gnu.org/licenses/lgpl.html
//
// You�re free to copy, distribute and make commercial use
// of this software under the following conditions:
//
// * You have to cite the author (and copyright owner): EmbeddedSW.net
// * You have to provide a link to the author�s Homepage: http://www.embeddedsw.net/libobfuscate.html
//
///////////////////////////////////////////////

#ifndef STDAFX_H
#define STDAFX_H

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions

#include <process.h>

#endif
