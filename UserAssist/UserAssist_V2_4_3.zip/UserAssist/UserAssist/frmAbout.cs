using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UserAssist
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            textBox1.Lines = new string[] 
            {
                @"The program UserAssist displays a list of the programs run by a user on Windows.",
                @"",
                @"Windows Explorer displays frequently used programs on the left side of the standard XP Start menu. ",
                @"The data about frequently used programs is kept in the registry under this key:",
                @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist",
                @"",
                @"This program decrypts and displays the data found in the registry under the UserAssist key.",
                @"",
                @"When started, the program retrieves the data for the current user and displays it. ",
                @"The display is not refreshed automatically when Windows Explorer updates the registry entries. ",
                @"To refresh the display, execute the 'Load from local registry' command.",
                @"",
                @"Columns in the listview:",
                @"Key: ",
                @"this value is {0D6D4F41-2994-4BA0-8FEF-620E43CD2812}, {5E6AB780-7743-11CF-A12B-00AA004AE837} or {75048700-EF1F-11D0-9888-006097DEACF9}",
                @"those are the keys found under the UserAssist key, and are included in the list view to distinguish the entries.",
                @"",
                @"Index:",
                @"a running counter, indicating the sequence of values in the registry",
                @"At first, the entries are listed in the sequence they appear in the registry. You can sort columns by clicking on the header.",
                @"To revert to the original sequence, sort the column Index and then the column Key",
                @"",
                @"Name:",
                @"The name of the value registry entry. This references the program that was run. This key is ROT13 encrypted, the displayed name is decrypted.",
                @"There is a registry setting to prevent encryption of the log, but this program does not support this setting.",
                @"",
                @"Unknown:",
                @"a 4 byte integer, meaning unknown. It appears to be present only for session entries (UEME_CTLSESSION).",
                @"",
                @"Session:",
                @"This is the ID of the session (a 4 byte integer).",
                @"",
                @"Counter:",
                @"This is the number of times the program was ran (a 4 byte integer).",
                @"",
                @"Last:",
                @"This is the last time the program was ran (a 8 byte datetime). ",
                @"The value is displayed with the timezone of the machine running this UserAssist tool.",
                @"Watch out for time zone differences when importing a REG file from a system with different regional settings.",
                @"",
                @"Last UTC:",
                @"This is the last time the program was ran (a 8 byte datetime) in UTC. ",
                @"",
                @"Commands:",
                @"",
                @"'Load from local registry'",
                @"Displays the data for the current user.",
                @"",
                @"'Load from REG file'",
                @"Loads a REG file and imports the UserAssist key. ",
                @"This command doesn't check the full path of the UserAssist key, thus allowing the analysis of NTUSER.DAT hives loaded and exported with another path.",
                @"Use this command if you cannot run the program on the machine you want to analyze.",
                @"Loading the data from a REG file disables editing commands.",
                @"",
                @"'Load from DAT file'",
                @"Loads a registry hive file (a DAT file like NTUSER.DAT) and imports the UserAssist key. ",
                @"The DAT file is temporarily loaded in the registry under the USERS\LoadedHive key. Be sure to have the local admin rights to access the file and load it.",
                @"Use this command if you cannot run the program on the machine you want to analyze.",
                @"Loading the data from a DAT file disables editing commands.",
                @"",
                @"'Highlight'",
                @"Allows you to type in a search string (a regular expression is accepted), each entry matching this string will be highlighted in red.",
                @"The highlighting stays active during reloads. Type an empty string to disable the highlighting.",
                @"",
                @"'Save'",
                @"This saves the data as a CSV file or a HTML file (choose file type).",
                @"",
                @"'Clear All'",
                @"This deletes the {5E6AB780-7743-11CF-A12B-00AA004AE837} and {75048700-EF1F-11D0-9888-006097DEACF9} keys.",
                @"All data is lost, and no new data is recorded until Windows Explorer is restarted.",
                @"This will impact the frequently run program list on your Start Menu, and maybe other things. I had no other side-effects on my test machines.",
                @"This command is disabled when a REG file is loaded.",
                @"",
                @"'Logging Disabled'",
                @"Enabling the 'Logging Disabled' toggle allows you to permanently disable the logging of user activity in the UserAssist keys by creating a value",
                @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist\Settings\NoLog equal to 1.",
                @"Disabling the 'Logging Disabled' removes the NoLog value (apparently, setting it to 0 doesn't prevent logging).",
                @"This setting is only effective after Windows Explorer is restarted.",
                @"This command is disabled when a REG file is loaded.",
                @"",
                @"'Load at Startup'",
                @"Enabling the 'Load at Startup' toggle instructs UserAssist to load the keys from the local registry when it starts up.",
                @"",
                @"Right-clicking an entry will display a menu:",
                @"",
                @"'Clear' will delete the selected entries. The index field of the remaining entries is not changed, they only change after reloading the registry.",
                @"This command is disabled when a REG file is loaded.",
                @"",
                @"'Explain' will analyse the contents of the name field and try to explain its meaning (based on empirical data).",
                @"",
                @"This program has been tested on Windows XP SP1, SP2, Windows 2003 and Windows Vista. ",
                @"Microsoft doesn't publish official documentation for UserAssist data. I've found info on the WWW (google for UserAssist) and I discovered the meaning of the binary data through trial-and-error testing.",
                @"In other words: use this program at your own risk.",
                @"",
                @"Ways to restart Windows Explorer:",
                @"1) Task Manager: kill the explorer.exe process and start a New Task explorer.exe",
                @"2) logoff / logon",
                @"3) reboot"            
            };
            linkLabel1.Text = UserAssist.URL;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkLabel1.Text);
        }
    }
}