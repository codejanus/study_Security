﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("UserAssist")]
[assembly: AssemblyDescription("Decrypt the UserAssist registry keys")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Didier Stevens (https://DidierStevens.com)")]
[assembly: AssemblyProduct("UserAssist")]
[assembly: AssemblyCopyright("Put in Public Domain by Didier Stevens")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("eb4cd0c0-d601-4d40-b99c-a80ac16ff4f0")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.6.0.0")]
[assembly: AssemblyFileVersion("2.6.0.0")]
