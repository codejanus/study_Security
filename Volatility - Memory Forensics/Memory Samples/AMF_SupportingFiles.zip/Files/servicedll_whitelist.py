import pywintypes, win32api, win32con

def main():
    read_perm = (win32con.KEY_READ | win32con.KEY_ENUMERATE_SUB_KEYS |
                 win32con.KEY_QUERY_VALUE)

    hkey = win32api.RegOpenKeyEx(win32con.HKEY_LOCAL_MACHINE,
                    "SYSTEM\\ControlSet001\\Services", 0,
                    read_perm)

    names = [data[0] for data in win32api.RegEnumKeyEx(hkey)]

    for name in names:
        try:
            subkey = win32api.RegOpenKeyEx(
                        hkey,
                        "%s\\Parameters" % name, 0,
                        read_perm)

            value = win32api.RegQueryValueEx(subkey,
                        "ServiceDll")

        except pywintypes.error: 
            continue

        path = win32api.ExpandEnvironmentStrings(value[0]) name = name.lower()
        path = path.lower()
        print name, "=", path

if __name__ == '__main__': 
    main()