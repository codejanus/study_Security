import volatility.utils as utils 
import volatility.commands as commands 
import volatility.win32.tasks as tasks

class ExamplePlugin(commands.Command): 
    """This is an example plugin"""

    def calculate(self):
    """This method performs the work"""

        addr_space = utils.load_as(self._config) 
        for proc in tasks.pslist(addr_space):
            yield proc

    def render_text(self, outfd, data):
        """This method formats output to the terminal.
        :param outfd | <file>
        data | <generator>
        """

        for proc in data:
            outfd.write("Process: {0}\n".format(proc.ImageFileName))