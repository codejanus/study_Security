(V1.1) Somarsoft DumpReg - dump NT registry
Windows NT and Windows 95 program to dump
the registry, making it easy to find keys 
and values matching a string. For Windows 
NT, dumped entries can be sorted by reverse 
order of last modified time, making it easy 
to see changes made by recently installed 
software. 

This is a free product.

See http://www.systemtools.com/somarsoft for 
further information on this product.
-----------------------------------

                                Overview

Somarsoft DumpReg is a program for Windows NT and Windows 95 that dumps the 
registry, making it easy to find keys and values containing a string. For
Windows NT, the registry entries can be sorted by reverse order of last
modified time, making it easy to see changes made by recently installed
software, for example. Must-have product for Windows NT systems administrators. 

                        Copyright/License/Registration

Somarsoft DumpReg is Copyright � 1995-1996 by Somarsoft, Inc. All Rights Reserved.

See http://www.systemtools.com/somarsoft for further information on this product.

Somarsoft DumpAcl is free.  No registration is required.

                           Installation/Uninstallation

Place DUMPREG.EXE and DUMPREG.HLP together in any directory. The first time 
DUMPREG.EXE is run, it will create a registry entry in the current user profile
to store the last window position and similar configuration information. Somarsoft
DumpReg does not make any other changes to your system.

To uninstall, run DUMPREG.EXE with /u as a command line parameter. This will 
delete the DumpReg registry entry. Then delete DUMPREG.EXE and DUMPREG.HLP
from your system.

