NTLast 3.0 is a security audit tool for use with Windows NT. It allows you to quickly scan logon information to determine 
who is logging on, attempting to logon, and when.

In order for NTLast to work, You must be the adminstrator of the machine who's log you are attempting to read. Auditing on 
that machine must be enabled through use of User Manager and there must be records in the log.

NTLast is very simple to use, just run the program from a command prompt with the desired switches.


Please see either the enclosed command list file, or run NTLast with the /? switch to view that available switches.

PUTTING NTLAST IN YOUR SYSTEM PATH IS A VERY USEFUL THING TO DO.

SETTING YOUR COMMAND LINE BUFFER TO 500 LINES OR MORE IS GOOD.



