Yasca
=====

Yet Another Source Code Analyzer

Installing Yasca
================

    Step 1: Download Yasca

Web Site
========

Visit the Yasca web site for the latest news and downloads:

    http://yasca.org

Downloadi