<?
declare(encoding='UTF-8');
namespace Yasca\Core;

final class EncodingException extends \Exception {
	/**
	 * https://wiki.php.net/rfc/class_name_scalars
	 */
	const _class = __CLASS__;
}