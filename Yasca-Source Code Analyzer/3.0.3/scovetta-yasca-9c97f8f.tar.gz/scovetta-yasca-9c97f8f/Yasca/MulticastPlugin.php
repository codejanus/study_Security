<?
declare(encoding='UTF-8');
namespace Yasca;

trait MulticastPlugin {
	abstract public function getResultIterator($path);
}