<?

exec("evil");
`evil`;
system("evil");
shell_exec("evil");
