class A {

    public void foo() {
	FileReader in = new FileReader();
	while( (line = in.readLine()) != null ) {
	}
    }

}