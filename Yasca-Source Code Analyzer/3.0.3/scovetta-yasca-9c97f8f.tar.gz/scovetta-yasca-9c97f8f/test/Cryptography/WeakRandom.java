class A {

    public double foo() {
	return Math.random();
    }

}