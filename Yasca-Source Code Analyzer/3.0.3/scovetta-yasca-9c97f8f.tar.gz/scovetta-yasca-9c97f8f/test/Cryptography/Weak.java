class A {

    public void foo(String s) {
	Crypto.encrypt(s, "MD5");
    }

}