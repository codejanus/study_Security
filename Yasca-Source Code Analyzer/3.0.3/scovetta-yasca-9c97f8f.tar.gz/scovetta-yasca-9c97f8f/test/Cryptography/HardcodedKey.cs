﻿using System;

public class Class1
{
	public Class1()
	{
        var encryptionkey = "23w5rtqa15f656a1sfafseasfeafeaewffwae";
	}
}
