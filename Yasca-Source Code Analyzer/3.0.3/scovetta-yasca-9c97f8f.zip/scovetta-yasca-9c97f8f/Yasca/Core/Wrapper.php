<?
declare(encoding='UTF-8');
namespace Yasca\Core;

interface Wrapper {
	public function unwrap();
}