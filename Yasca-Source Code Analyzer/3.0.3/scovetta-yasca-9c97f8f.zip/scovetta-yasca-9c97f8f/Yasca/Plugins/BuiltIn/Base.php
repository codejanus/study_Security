<?
declare(encoding='UTF-8');
namespace Yasca\Plugins\BuiltIn;

trait Base {
	abstract protected function newResult();
}