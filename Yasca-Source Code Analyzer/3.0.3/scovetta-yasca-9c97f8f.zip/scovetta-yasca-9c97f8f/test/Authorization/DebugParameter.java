class A {
    public void foo() {
    	if (this.request.getParameter("hiddendebug") == "true"){
    		
    	}
    }
}