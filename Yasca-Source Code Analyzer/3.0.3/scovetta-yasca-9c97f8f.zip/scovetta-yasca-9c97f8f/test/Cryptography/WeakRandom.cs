﻿using System;

public class Class1
{
	public Class1()
	{
        var r = new Random();
	}
}
