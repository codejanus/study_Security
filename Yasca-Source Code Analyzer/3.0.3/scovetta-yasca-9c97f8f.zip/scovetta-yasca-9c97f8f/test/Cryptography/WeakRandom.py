import random


class A:
    print random.random()
    x = random.random()
