config.action_dispatch.session = {
  :key    => '_app_session',
  :secret => '0x01'
}

config.action_dispatch.session = {
  :key    => '_app_session',
  :secret => '0x0dkfj3927dkc7djdh36rkckdfzsgasjhfkhgkjsdgs'
}
