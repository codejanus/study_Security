<?
$encryptionKey = '234qasfasfajoij980456sfdaszfdvzsdf053g1';
$encryptionKey = "234qasfasfajoij980456sfdaszfdvzsdf053g1";
$encryptionKey = <<<'EEE'
234qasfasfajoij980456sfdaszfdvzsdf053g1
EEE;
