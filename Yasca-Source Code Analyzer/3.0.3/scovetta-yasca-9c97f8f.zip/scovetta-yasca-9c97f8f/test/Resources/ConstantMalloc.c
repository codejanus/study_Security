
void getFoo() {
    int* test = malloc(100);
}