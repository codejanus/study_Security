
void getFoo(char* x) {
	FILE* f = fopen(x);
}