public class JLintTest {
    public static void main(String[] args) {
	boolean b = false;

	String s = (b ? "mike" : null).toLowerCase();
    }
}