StegoMagic 1.0
**************

How to use StegoMagic
---------------------   

Hiding Message
--------------
1.Select the "Message" radio button.
2.Type the message in the message box provided.
3.Select Carrier File Type.
4.Browse and select the carrier file(File into which message to be hidden).
5.Enter Password.
6.Select the file name (with extension) of the resultant carrier file
  (Containing hidden message).
7.Click on "Hide" button.
8.Wait till the message "Hiding Successfully Completed" appears.
9.Now your message is hidden in the carrier file.

Unhiding Message
----------------

1.Select the "Message" radio button.
2.Select Carrier File Type.
3.Browse and select the carrier file(File in which message is hidden).
4.Enter Password.
5.Click on "UnHide" button.
6.Wait till the message "Unhiding Successfully Completed" appears.
7.Now your message is displayed in the message box.

Hiding File
-----------

1.Select the "File" radio button.
2.Browse and select the secret file.
3.Select Carrier File Type.
4.Browse and select the carrier file(File into which file to be hidden).
5.Enter Password.
6.Select the file name (with extension) of the resultant carrier file
  (Containing hidden file).
7.Click on "Hide" button.
8.Wait till the message "Hiding Successfully Completed" appears.
9.Now your file is hidden in the carrier file.

Unhiding File
-------------

1.Select the "File" radio button.
2.Select Carrier File Type.
3.Browse and select the carrier file(File in which message is hidden).
4.Enter file name of the resultant secret file (from the carrier file).
5.Enter Password.
6.Click on "UnHide" button.
7.Wait till the message "Unhiding Successfully Completed" appears.
8.Now your secret file has been extracted to specified directory.

Note:-Check the properties of the bmp image before selecting the type
(24 bit or 256 colours).