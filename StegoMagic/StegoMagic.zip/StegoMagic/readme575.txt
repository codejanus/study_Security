StegoMagic  1.0
---------------

By 

Anoop.S.
Shibin.K.
Varun Suresh
Vivek.K.P

2002-2006 Batch,
College of Engineering,
Trivandrum.

   StegoMagic Hides any kind of file or message in TEXT, WAV ,BMP 24 bit and BMP 256 
colour files.There will be NO CAHANGE IN FILE SIZE of the 
carrier medium except when text file is the carrier medium.
THERE WILL NOT BE ANY PERCEPTIBLE DISTORTION IN THE CARRIER FILE AFTER HIDING.
YOUR FILE WILL SEEM EXACTLY AS THE ORIGINAL, so it's  almost impossible to 
detect hidden data.Your data is encrypted with a 
password using DES  (for additional protection) and hidden 
in the carrier medium.The data to be hidden 
must be approximately 1/8th of carrier file size or less.
No file size restriction for Text 
File carrier files.User friendly GUI provided.StegoMagic 
runs on all Microsoft Windows versions.