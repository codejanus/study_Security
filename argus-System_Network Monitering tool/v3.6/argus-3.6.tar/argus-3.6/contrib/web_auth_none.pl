# -*- perl -*-

# Copyright (c) 2002 by Jeff Weisberg
# Author: Jeff Weisberg <argus @ tcp4me.com>
# Date: 2002-Sep-17 18:40 (EDT)
# Function: access argus without login
#
# $Id: web_auth_none.pl,v 1.1 2004/09/18 20:03:36 jaw Exp jaw $


# empty file

