
$datadir = '__DATADIR__';
$libdir  = '__LIBDIR__';
$wwwdir  = '__WWWDIR__';
$path_fping = '__FPING__';
$path_fping6 = '__FPING6__';
$path_qpage = '__QPAGE__';
$path_sendmail = '__SENDMAIL__';
$ARGUS_URL = 'http://argus.tcp4me.com';
$VERSION = '__VERSION__';

1;
