# -*- perl -*-

# Copyright (c) 2011
# Author: Jeff Weisberg <argus @ tcp4me.com>
# Created: 2011-Oct-15 14:21 (EDT)
# Function: holt-winters abberant behavior detection
#
# $Id: Argus::HWAB.pm,v 1.6 2011/11/03 02:13:40 jaw Exp $

package Argus::HWAB;
use POSIX;
use strict;

my $TWIN        = 300;
my $TWOWEEKS    = 2 * 7 * 24 * 3600;
my $START       = $^T;
my $BOOTK       = 0.025;
my $BOOTDK	= 0.90;
my $LONGK       = 0.0005;
my $KDEVIANT    = 1.5;
my $SMOOTH      = 1;

my %DB;
my $db;
my $init;

sub init {

    # init on first use
    return if $init;
    $init = 1;

    # tie db file
    my $file = "$::datadir/stats/hwab.db";

    $db = tie %DB, $::DATABASE, $file or die "cannot tie $file: $!\n";
    ::loggit( "loading holt/winters from $file", 0);

    _cleanup();

    Cron->new( freq 	=> 35 * 3600,
               info	=> 'clean up hwab file',
               func	=> \&_cleanup,
    );
}

END {
    $db = undef;
    untie %DB;
}

sub _cleanup {

    # clean out old/unused entries
    my %del;
    while( my($k,$v) = each %DB ){
        next unless /cstart$/;

        (my $kk = $k) =~ s|/cstart$||;
        next if $v > $^T - $TWOWEEKS;
        $del{$kk} = $v;
    }

    _delete( $_ ) for keys %del;
    sync();
}

sub _delete {
    my $key = shift;

    # ::loggit("no longer keeping H/W data: $key", 0);

    my $buckets = $DB{"$key/buckets"};
    for my $k ('a', 'a boot', 'ab', 'b', 'b boot', 'c boot', 'd boot', 'created', 'cstart', 'conf', 'buckets'){
        delete $DB{"$key/$k"};
    }

    for my $i (0 .. $buckets){
        delete $DB{"$key/c $i"};
        delete $DB{"$key/d $i"};
        delete $DB{"$key/cd $i"};
    }
}

sub new {
    my $class  = shift;
    my $name   = shift;
    my $period = shift;
    my $alpha  = shift;
    my $beta   = shift;
    my $gamma  = shift;
    my $xdelta = shift;
    my $debug  = shift;

    init();

    my $me = bless {
        name		=> $name,
        period		=> $period,
        period_boot	=> $period * 2,
        buckets		=> $period / $TWIN,
        twin		=> $TWIN,
        alpha		=> $alpha,
        beta		=> $beta,
        gamma		=> $gamma,
        xdelta  	=> $xdelta,
        debug		=> $debug,
    }, $class;

    $me->debug("new: $alpha, $beta, $gamma");
    $me->_start();

    return $me;
}

sub debug {
    my $me  = shift;
    my $msg = shift;

    return unless $me->{debug};
    $me->{debug}->("hwab $msg");
}

sub _key {
    my $me  = shift;
    my $key = shift;

    return "$me->{name}/$key";
}

sub _put {
    my $me  = shift;
    my $key = shift;
    my $val = shift;

    $DB{ $me->_key($key) } = $val;
}

sub sync {
    $db->sync();
}

sub _get {
    my $me  = shift;
    my $key = shift;

    return $DB{ $me->_key($key) };
}

sub _put_ab {
    my $me  = shift;
    my( $a, $b ) = @_;

    $me->_put('ab', "$a,$b");
}

sub _get_ab {
    my $me  = shift;

    my $ab = $me->_get('ab');
    if( $ab ){
        my($a, $b) = split /,/, $ab;
        return ($a, $b);
    }
    return ( $me->_get('a'), $me->_get('b') );
}

sub _put_cd {
    my $me  = shift;
    my $si  = shift;
    my( $c, $d ) = @_;

    $me->_put("cd $si", "$c,$d");
}

sub _get_cd {
    my $me  = shift;
    my $si  = shift;

    my $cd = $me->_get("cd $si");
    if( $cd ){
        my($c, $d) = split /,/, $cd;
        return ($c, $d);
    }
    return ( $me->_get("c $si"), $me->_get("d $si") );
}

sub _start {
    my $me   = shift;

    # initialize

    return if $me->{current};

    # reset if params change
    my $new_conf = ref($me) . ";$me->{twin},$me->{period},$me->{alpha},$me->{beta},$me->{gamma}";
    my $old_conf = $me->_get('conf');

    if( $old_conf && $new_conf ne $old_conf ){
        $me->debug("config changed. reseting ($old_conf)");
        _delete( $me->{name} );
    }

    my $create = $me->_get('created');

    $me->_put('conf', $new_conf) if !$create || !$old_conf;

    unless( $create ){
        $create = int($^T);

        $me->_put('created', $create);
        $me->_put('cstart',  $create);
        $me->_put('buckets', $me->{buckets});	# for cleanup
    }

    $me->{created} = $create;

    $me->{current} = {
        start	=> $me->_get('cstart'),
    };

    # extended downtime?
    if( $^T - $me->{current}{start} > 5 * $me->{twin} ){

        my($at,$bt) = $me->_get_ab();
        if( $at ){
            my $adj = int( ($^T - $me->{current}{start}) / $me->{twin} ) - 1;
            $me->{current}{start} += $adj * $me->{twin};
            $me->_put_ab($at + $adj*$bt, $bt);
        }else{
            # do nothing during boot phase?
        }
    }


    $me->_init_expect();

}

sub MAX {
    my $max = shift;

    for my $x (@_){
        $max = $x if $x > $max;
    }
    return $max;
}

# initialize params
sub _bootstrap {
    my $me  = shift;
    my $val = shift;
    my $si  = shift;

    my $age    = $me->{current}{start} - $me->{created};
    my $nsamp  = $age / $me->{twin};

    my $btb = $me->_get("b boot");
    my($ctp, $dtp) = $me->_get_cd($si);
    my $ctb = $me->_get("c boot");
    my $dtb = $me->_get("d boot");
    $ctp = $val unless defined $ctp;
    $ctb = $val unless defined $ctb;
    # C = smoothed average observed value
    my $ct  = ($val + $ctp + $ctb) / 3;
    # D = maximum observed deviation
    my $dtx = MAX( abs($val - $ct), abs($val - $ctp), abs($val - $ctb), abs($ctb - $ctp) );
    my $dt  = MAX( $dtp, 2 * $dtx, $dtb*$BOOTDK );
    $btb += $val - $ctb;
    # B = average derivative
    my $bt  = $btb / ($nsamp + 1);

    # A = intercept of B*t
    $me->_put_ab($nsamp * $bt, $bt);
    $me->_put_cd($si, $ct, $dt);
    $me->_put("b boot", $btb);
    $me->_put("c boot", $val);
    $me->_put("d boot", $dt);

    $me->{expect} = {
        y	=> $ct,
        d	=> $dt,
    };
}

# smooth out c[]. just a little bit.
sub _smooth_c {
    my $me = shift;
    my $si = shift;

    $me->debug("smoothing $si");
    my $max = $me->{buckets};
    $si --;

    my $tot;
    my $cnt;
    for my $j (- $SMOOTH .. $SMOOTH){
        my $i = ($si + $j + $max) % $max;
        my $v = $me->_get("c $i");
        next unless defined $v;
        my $k = $j ? 1 : 2;	# weighed average
        $tot += $v * $k;
        $cnt += $k;
    }

    return unless $cnt;
    $me->_put("c $si", $tot / $cnt);
}

sub _init_expect {
    my $me = shift;

    my $si      = ($me->{current}{start} / $me->{twin}) % $me->{buckets};

    my($atp, $btp) = $me->_get_ab();
    my($ctp, $dtp) = $me->_get_cd($si);

    return unless $atp && $btp && $ctp && $dtp;

    $me->{expect} = {
        y	=> $atp + $btp + $ctp,
        d	=> $dtp,
    };
}


sub _hw {
    my $me  = shift;
    my $val = shift;
    my $now = shift;

    my $buckets = $me->{buckets};
    my $si      = ($me->{current}{start} / $me->{twin}) % $buckets;
    my $age     = $me->{current}{start} - $me->{created};
    my $nsp     = $age % $buckets;
    my $nsamp   = $age / $me->{twin};

    $me->debug("hw $val, si $si");

    return $me->_bootstrap($val, $si) if $age < $me->{period_boot};

    my($atp, $btp) = $me->_get_ab();
    my($ctp, $dtp) = $me->_get_cd($si);

    # missing data - something stopped during boot phase, patch hole
    unless( defined $ctp ){
        my $max = $me->{buckets};
        my $pi = ($si - 1 + $max) % $max;
        my($cx, undef) = $me->_get_cd($pi);
        $cx  = $val unless defined $cx;
        $ctp = $dtp = $BOOTK * $val + (1 - $BOOTK) * $cx;
    }

    my $yt = $atp + $btp + $ctp;
    my $at = $me->{alpha} * ($val - $ctp)        +  (1 - $me->{alpha}) * ($atp + $btp);
    my $bt = $me->{beta}  * ($val - $ctp - $atp) +  (1 - $me->{beta})  * $btp;
    my $ct = $me->{gamma} * ($val - $atp - $btp) +  (1 - $me->{gamma}) * $ctp;
    my $dt = $me->{gamma} * abs($val - $yt)      +  (1 - $me->{gamma}) * $dtp;

    my $nsi = ($si + 1) % $buckets;
    my($ctn, undef) = $me->_get_cd($nsi);
    my $ytn = $at + $bt + $ctn;

    $me->debug("hw $at, $bt, $ct, $dt => $ytn");

    $me->_put_ab($at, $bt);
    $me->_put_cd($si, $ct, $dt);

    $me->_smooth_c( $si );

    $me->{expect} = {
        y	=> $ytn,
        d	=> $dt,
    };

}


sub add {
    my $me  = shift;
    my $val = shift;

    my $now = $^T;

    $me->debug("add $val");
    $me->{current}{count} ++;
    $me->{current}{total} += $val;

    my $ave = $me->_use_value($me->{current}{total} / $me->{current}{count});

    while( $me->{current}{start} + $me->{twin} <= $now ){
        $me->_hw($ave, $now);

        $me->{current}{count} = $me->{current}{total} = 0;
        $me->{current}{start} += $me->{twin};
        $me->_put('cstart', $me->{current}{start});
    }

}

# limit the impact of deviant values
sub _use_value {
    my $me  = shift;
    my $val = shift;

    my $d = $me->deviation($val);
    return $val unless $d && $d > $me->{xdelta} * $KDEVIANT;

    my $sign =  ($val > $me->{expect}{y}) ? 1 : -1;
    return $me->{expect}{y} + $sign * $KDEVIANT * $me->{expect}{d} * $me->{xdelta};
}

# how aberant are we?
sub deviation {
    my $me  = shift;
    my $val = shift;

    # too soon to tell?
    return unless $me->{current};
    return unless $me->{expect};
    return unless $me->{expect}{d};
    my $elapsed = $me->{current}{start} - $me->{created};
    return unless $elapsed > $me->{period_boot};

    my $d = abs($me->{expect}{y} - $val);
    my $a = $d / $me->{expect}{d};

    return $a;
}

sub age {
    my $me = shift;

    return $^T - $me->{created};
}


1;
