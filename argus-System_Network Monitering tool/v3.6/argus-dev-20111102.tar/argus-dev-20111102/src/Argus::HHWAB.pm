# -*- perl -*-

# Copyright (c) 2011
# Author: Jeff Weisberg <argus @ tcp4me.com>
# Created: 2011-Oct-15 14:21 (EDT)
# Function: holt-winters abberant behavior detection
#
# $Id: Argus::MHWAB.pm,v 1.1 2011/10/25 04:06:47 jaw Exp $

package Argus::MHWAB;
our @ISA = qw(Argus::HWAB);
use POSIX;
use strict;

my $TWIN        = 300;
my $PERIOD      = 7 * 24 * 3600;
my $PERIOD_BOOT = 2 * $PERIOD;
my $TWOWEEKS    = 2 * 7 * 24 * 3600;
my $BOOTK       = 0.025;
my $BOOTDK	= 0.90;
my $EPSILON     = 0.0001;

sub MAX {
    my $max = shift;

    for my $x (@_){
        $max = $x if $x > $max;
    }
    return $max;
}

# initialize params
sub _bootstrap {
    my $me  = shift;
    my $val = shift;
    my $si  = shift;

    my $age    = $me->{current}{start} - $me->{created};
    my $nsamp  = $age / $me->{twin};

    my $btb = $me->_get("b boot");
    my $ctp = $me->_get("c $si");
    my $dtp = $me->_get("d $si");
    my $ctb = $me->_get("c boot");
    my $dtb = $me->_get("d boot");
    $ctp = $val unless defined $ctp;
    $ctb = $val unless defined $ctb;
    # C = smoothed average observed value
    my $ct  = ($val + $ctp + $ctb) / 3;
    # D = maximum observed deviation
    my $dtx = MAX( abs($val - $ct), abs($val - $ctp), abs($val - $ctb), abs($ctb - $ctp) );
    my $dt  = MAX( $dtp, 2 * $dtx, $dtb*$BOOTDK );
    $btb += $ctp ? $val / $ctp : 1;
    # B = average ratio
    my $bt  = $btb / ($nsamp + 1);

    $me->_put("a", 1);
    $me->_put("b", $nsamp ? ($bt - 1) / ($nsamp/2) : 0);
    $me->_put("b boot", $btb);
    $me->_put("c $si",  $ct);
    $me->_put("d $si",  $dt);
    $me->_put("c boot", $val);
    $me->_put("d boot", $dt);

    $me->{expect} = {
        y	=> $ct,
        d	=> $dt,
        v	=> $val,
    };
}

sub _hw {
    my $me  = shift;
    my $val = shift;
    my $now = shift;

    my $period = $PERIOD / $me->{twin};
    my $si     = ($me->{current}{start} / $me->{twin}) % $period;
    my $age    = $me->{current}{start} - $me->{created};
    my $nsp    = $age % $period;
    my $nsamp  = $age / $me->{twin};

    $me->debug("hw $val, si $si");

    return $me->_bootstrap($val, $si) if $age < $PERIOD_BOOT;

    my $atp = $me->_get("a");
    my $btp = $me->_get("b");
    my $ctp = $me->_get("c $si");
    my $dtp = $me->_get("d $si");

    # missing data - something stopped during boot phase, patch hole
    unless( defined $ctp ){
        my $max = $PERIOD / $TWIN;
        my $pi = ($si - 1 + $max) % $max;
        my $cx = $me->_get("c $pi");	# previous value
        $cx  = $val unless defined $cx;
        $ctp = $dtp = $BOOTK * $val + (1 - $BOOTK) * $cx;
    }

    my $btn = $btp * $nsamp;
    my $yt  = ($atp + $btn) * $ctp;

    my($at, $bt);
    if( abs($ctp) > 1 ){
        $at = $me->{alpha} * ($val / $ctp - $btn)           +  (1 - $me->{alpha}) * $atp;
        $bt = $me->{beta}  * ($val / $ctp - $atp) / $nsamp  +  (1 - $me->{beta})  * $btp;

    }else{
        $at = $atp;
        $bt = $btp;
    }

    if( $at + $bt * $nsamp < $EPSILON ){
        # QQQ - excessive shrinkage. reset+start over?
        $at = $EPSILON - $bt * $nsamp;
    }

    my $ct = $me->{gamma} * ($val / ($atp + $btn)) +  (1 - $me->{gamma}) * $ctp;
    my $dt = $me->{gamma} * abs($val - $yt)        +  (1 - $me->{gamma}) * $dtp;

    my $nsi = ($si + 1) % $period;
    my $ytn = ($at + $bt * ($nsamp+1)) * $me->_get("c $nsi");

    $me->debug("hw $at, $bt*$nsamp, $ct, $dt => $ytn");

    $me->_put("a", $at);
    $me->_put("b", $bt);
    $me->_put("c $si", $ct);
    $me->_put("d $si", $dt);

    $me->_smooth_c( $si );

    $me->{expect} = {
        y	=> $ytn,
        d	=> $dt,
        v	=> $val,
    };

}

sub _use_value {
    my $me  = shift;
    my $val = shift;

    return $val;
}

1;
