# -*- perl -*-

# Copyright (c) 2002 by Jeff Weisberg
# Author: Jeff Weisberg <argus @ tcp4me.com>
# Date: 2002-Sep-17 18:40 (EDT)
# Function: access argus without login
#
# $Id: web_auth_none.pl,v 1.1 2011/10/29 15:36:13 jaw Exp $


# empty file

