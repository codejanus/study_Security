pref("InBasic.PhProxy.def_URL_F", 'http://olylimited.com/');
pref("InBasic.PhProxy.def_URL", 'http://olylimited.com/');

pref("InBasic.PhProxy.LeftClick", '0') ;

pref("InBasic.PhProxy.infoShow", '0') ;

pref("InBasic.PhProxy.Ph_Filter_Rules", '') ;

pref("InBasic.PhProxy.C_Check1", false);
pref("InBasic.PhProxy.C_Check2", false) ;
pref("InBasic.PhProxy.C_Check3", true) ;
pref("InBasic.PhProxy.boolImage", true);
pref("InBasic.PhProxy.C_Check5", true) ;
pref("InBasic.PhProxy.C_Check6", false);
pref("InBasic.PhProxy.C_Check7", false);
pref("InBasic.PhProxy.C_Check8", true) ;



pref("InBasic.PhProxy.URL01", 'http://blog.klukec.net/') ;
pref("InBasic.PhProxy.URL02", 'http://www.unlock-bebo.net/') ;
pref("InBasic.PhProxy.URL03", 'http://www.youhide.info/') ;
pref("InBasic.PhProxy.URL04", 'http://abrownproxy.info/') ;
pref("InBasic.PhProxy.URL05", 'http://yellowproxify.info/') ;
pref("InBasic.PhProxy.URL06", 'http://bluenoblock.info/') ;
pref("InBasic.PhProxy.URL07", 'http://greensneak.info/') ;
pref("InBasic.PhProxy.URL08", 'http://awhiteproxy.info/') ;

pref("InBasic.PhProxy.UpdateVer", '0') ;

pref("InBasic.PhProxy.NewPHP", true) ;