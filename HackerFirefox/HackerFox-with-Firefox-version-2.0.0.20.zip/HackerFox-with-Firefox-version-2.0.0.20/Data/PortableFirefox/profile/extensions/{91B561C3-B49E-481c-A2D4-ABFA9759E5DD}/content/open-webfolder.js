// Open a Microsoft Webfolder using IE's "folder" behaviour

var ie = new ActiveXObject("InternetExplorer.Application");

ie.Navigate("about:blank");
var doc = ie.Document;

var folder = doc.createElement("span");
folder.addBehavior("#default#httpFolder");

var result = folder.navigate(WScript.Arguments(0));

if (result != "OK") {
  if (result == "PROTOCOL_NOT_SUPPORTED") {
    WScript.Echo("This site doesn't seem to support WebDAV.");
    WScript.Quit(1);
  }
  else {
    WScript.Echo("Unexpected status: " + result);
    WScript.Quit(2);
  }
}

