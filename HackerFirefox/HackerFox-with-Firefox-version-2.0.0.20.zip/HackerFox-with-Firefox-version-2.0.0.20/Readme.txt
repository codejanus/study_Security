The Hacker Fox based on Firefox 2.0.0.20 - update release 2013-05


Caution:
==========
This hackerfox is designed for practicing web insecurity exercises in controlled virtual  environment. Due to heavy memory footprint in latest/later version of Firefox and incompatibility of some addons with new versions of Firefox, based Firefox version was not updated to the currently available latest version. You are adviced not to visit to unknown web sites with this browser. 


Changes
==========
Addons were updated. WebGoat bookmarks were added. New version naming change was introduced so that you can easily know which Firefox version was based.  If you find suspicious packages or files, report immediately to us via report at yehg.net. 


Updated Addons
=================
Only basic extensions are enabled. 

1. Firebug
2. Googlebar Lite
3. HackBar 
4. JavaScript Debugger
5. NF-Tools (Removed in this version; Not Compatible)
6. LiveHttpHeaders
7. ServerSpy
8. Selenuim IDE (Removed in this version; Not Compatible)
9. PhProxy
10. SwitchProxy
11. FireEncrypter
12. InFormEnter
13. SuperDragAndGo
14. TamperData
15. WebDevloper
16. Technika
17. ViewSource Chart
18. UserAgent Switcher
19. ShowIP
20. GreaseMonkey
21. OpenAsWebFolder


New Addons since 1.5.12
=========================

1. XSS-Me
2. SQL Inject-Me
3. Access-Me

Compiled & Packed by 
YGN Ethical Hacker Group