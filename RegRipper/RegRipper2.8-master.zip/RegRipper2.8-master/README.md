RegRipper2.8
============

RegRipper version 2.8

This is the GitHub repository for RegRipper version 2.8
